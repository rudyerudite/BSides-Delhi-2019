#Welcome 

### Run the script and get yourself started 


