#Smalleeeee

### Bob forgot the primes, can you help him out?

> Hint: Do you really think you need to factor n this time?

