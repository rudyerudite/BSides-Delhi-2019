#ComMod

### Alice sent messages to his two friends, Bob and John. Can you figure out what the message was?

> Hint: Check the public modulus!

