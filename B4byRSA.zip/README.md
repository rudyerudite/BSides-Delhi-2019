#B4byRSA

### Prime factors are really powerful, ain't they?

> Hint: Factors....hmmm

