from Crypto.Util.number import *
from secret import flag

n = 654471739068178448980772379815154834252487704812848929908377787279918373063496090868243945370954692677799224177214164890352953754766868273185658597928726385693L

e = 65537

m = bytes_to_long(flag)

ciphertext = long_to_bytes(pow(m, e, n))
ciphertext = ciphertext.encode("hex")

obj = open("ciphertext.txt", "w")
obj.write(ciphertext)



